
package giaodienchuan.model.FrontEnd.Test.QLSV;


public class SinhVien {
    String mssv, ho, ten;
    
    public SinhVien(String mssv, String ho, String ten) {
        this.mssv = mssv;
        this.ho = ho;
        this.ten = ten;
    }

    public String getMssv() {
        return mssv;
    }

    public void setMssv(String mssv) {
        this.mssv = mssv;
    }

    public String getHo() {
        return ho;
    }

    public void setHo(String ho) {
        this.ho = ho;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }
    
}
