
package giaodienchuan.model.FrontEnd.NavBar;

import java.awt.Color;
import java.awt.Rectangle;

public class NavBarSeperator extends NavBarItem {
    
    public NavBarSeperator(Rectangle rec) {
        super(rec, "");
        setBackground(new Color(150, 150, 150));
    }
    
}
