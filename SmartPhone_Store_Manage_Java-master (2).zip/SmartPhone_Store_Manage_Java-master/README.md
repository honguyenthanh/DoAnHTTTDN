# ĐỒ ÁN JAVA - QUẢN LÝ ĐIỆN THOẠI

### *THÀNH VIÊN NHÓM*:

Stt | Mã sinh viên | Tên
---- | ---- | ---
1 | 3117410091 | [Trần Văn Hoàng](https://www.facebook.com/profile.php?id=100004848287494)
2 | 3117410057 | [Trần Thanh Giang](https://www.facebook.com/thanhgiang.tran.1276)
3 | 3117410110 | [Nguyễn Thiên Hữu](https://www.facebook.com/thienhuu.nguyen.10420)
4 | 3117410097 | [Hứa Hoàng Huy](https://www.facebook.com/hua.hoanghuy.7)

### *HƯỚNG DẪN, CÀI ĐẶT VÀ CHẠY THỬ*:

Các bạn vui lòng tải về và xem file `Tổng quan về đồ án.docx` hoặc `Tổng quan về đồ án.doc` nếu không xem được `.docx`

[VIDEO hướng dẫn](https://www.loom.com/share/4993ded95b9f4a1abc8af7704516057b)

### *SCREENSHOTS:*
![Login](screenshots/login.png)
![Main](screenshots/main.png)
![Products](screenshots/products.png)
![Sell](screenshots/sell.png)
![Phan quyen](screenshots/phanquyen.png)
 
<!--stackedit_data:
eyJoaXN0b3J5IjpbODU0NzMwMzE3LDE4MjgyMjM5NjMsLTQ2Nj
g0MjA2LC0zODY5MDg0OTEsLTMwNjYyNzNdfQ==
-->
